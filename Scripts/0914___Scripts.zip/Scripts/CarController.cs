using UnityEngine;

public class CarController : MonoBehaviour
{
    [Header("References")]
    public Rigidbody carRigidbody;

    [Header("Driving Settings")]
    public float motorForce = 1500f;
    public float brakeForce = 2500f;
    public float steerTorque = 400f;
    public float maxSpeed = 25f;

    [Header("Stability")]
    public float downforce = 50f;
    public float linearDrag = 0.1f;
    public float angularDrag = 1f;

    void Awake()
    {
        if (carRigidbody == null)
        {
            carRigidbody = GetComponent<Rigidbody>();
        }

        if (carRigidbody != null)
        {
            carRigidbody.drag = linearDrag;
            carRigidbody.angularDrag = angularDrag;
            carRigidbody.maxAngularVelocity = 7f;
        }
    }

    public void ResetCar(Vector3 position, Quaternion rotation)
    {
        transform.SetPositionAndRotation(position, rotation);
        if (carRigidbody == null) return;
        carRigidbody.velocity = Vector3.zero;
        carRigidbody.angularVelocity = Vector3.zero;
    }

    public void Move(float steer, float accel)
    {
        if (carRigidbody == null) return;

        steer = Mathf.Clamp(steer, -1f, 1f);
        accel = Mathf.Clamp(accel, -1f, 1f);

        // Forward/backward force (treat negative accel as braking)
        Vector3 forward = transform.forward;
        float speed = carRigidbody.velocity.magnitude;

        if (accel >= 0f)
        {
            if (speed < maxSpeed)
            {
                carRigidbody.AddForce(forward * (accel * motorForce), ForceMode.Force);
            }
        }
        else
        {
            // Simple brake by applying opposite force proportional to current velocity
            Vector3 brakeDir = -carRigidbody.velocity.normalized;
            carRigidbody.AddForce(brakeDir * (Mathf.Abs(accel) * brakeForce), ForceMode.Force);
        }

        // Steering via yaw torque
        carRigidbody.AddTorque(Vector3.up * (steer * steerTorque), ForceMode.Force);

        // Add simple downforce for stability
        carRigidbody.AddForce(-Vector3.up * downforce, ForceMode.Force);
    }

    public Vector3 GetLocalVelocity()
    {
        if (carRigidbody == null) return Vector3.zero;
        return transform.InverseTransformDirection(carRigidbody.velocity);
    }

    public float GetSpeed()
    {
        if (carRigidbody == null) return 0f;
        return carRigidbody.velocity.magnitude;
    }
}


