import os
import time
import math
from dataclasses import dataclass
from typing import Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from mlagents_envs.environment import UnityEnvironment
from mlagents_envs.environment import ActionTuple


@dataclass
class PPOConfig:
    total_timesteps: int = 400_000
    rollout_steps: int = 4096
    minibatch_size: int = 256
    ppo_epochs: int = 10
    gamma: float = 0.99
    gae_lambda: float = 0.95
    clip_coef: float = 0.2
    learning_rate: float = 3e-4
    value_coef: float = 0.5
    entropy_coef: float = 0.00
    max_grad_norm: float = 0.5
    device: str = "cuda" if torch.cuda.is_available() else "cpu"
    base_port: int = 5004  # Unity Editor default port


class ActorCritic(nn.Module):
    def __init__(self, obs_size: int, action_size: int):
        super().__init__()
        hidden = 128
        self.body = nn.Sequential(
            nn.Linear(obs_size, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
        )
        self.mu_head = nn.Linear(hidden, action_size)
        self.value_head = nn.Linear(hidden, 1)
        # Learnable log_std per action dim
        self.log_std = nn.Parameter(torch.zeros(action_size))

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        h = self.body(x)
        mu = torch.tanh(self.mu_head(h))  # range [-1,1]
        value = self.value_head(h).squeeze(-1)
        std = torch.exp(self.log_std)
        return mu, std, value

    def act(self, x: torch.Tensor):
        mu, std, value = self.forward(x)
        dist = torch.distributions.Normal(mu, std)
        action = dist.sample()
        log_prob = dist.log_prob(action).sum(-1)
        action_clipped = torch.clamp(action, -1.0, 1.0)
        return action_clipped, log_prob, value

    def evaluate_actions(self, x: torch.Tensor, actions: torch.Tensor):
        mu, std, value = self.forward(x)
        dist = torch.distributions.Normal(mu, std)
        log_prob = dist.log_prob(actions).sum(-1)
        entropy = dist.entropy().sum(-1)
        return log_prob, entropy, value


class RolloutBuffer:
    def __init__(self, capacity: int, obs_dim: int, act_dim: int, device: str):
        self.device = device
        self.capacity = capacity
        self.ptr = 0
        self.full = False
        self.obs = torch.zeros((capacity, obs_dim), dtype=torch.float32, device=device)
        self.actions = torch.zeros((capacity, act_dim), dtype=torch.float32, device=device)
        self.logprobs = torch.zeros((capacity,), dtype=torch.float32, device=device)
        self.rewards = torch.zeros((capacity,), dtype=torch.float32, device=device)
        self.dones = torch.zeros((capacity,), dtype=torch.float32, device=device)
        self.values = torch.zeros((capacity,), dtype=torch.float32, device=device)
        self.advantages = torch.zeros((capacity,), dtype=torch.float32, device=device)
        self.returns = torch.zeros((capacity,), dtype=torch.float32, device=device)

    def add(self, obs, action, logprob, reward, done, value):
        self.obs[self.ptr] = obs
        self.actions[self.ptr] = action
        self.logprobs[self.ptr] = logprob
        self.rewards[self.ptr] = reward
        self.dones[self.ptr] = float(done)
        self.values[self.ptr] = value
        self.ptr += 1
        if self.ptr >= self.capacity:
            self.full = True

    def compute_gae(self, last_value: float, gamma: float, lam: float):
        last_adv = 0.0
        for t in reversed(range(self.ptr)):
            next_non_terminal = 1.0 - self.dones[t]
            next_value = last_value if t == self.ptr - 1 else self.values[t + 1]
            delta = self.rewards[t] + gamma * next_value * next_non_terminal - self.values[t]
            last_adv = delta + gamma * lam * next_non_terminal * last_adv
            self.advantages[t] = last_adv
        self.returns[: self.ptr] = self.advantages[: self.ptr] + self.values[: self.ptr]
        # Normalize advantages
        adv = self.advantages[: self.ptr]
        self.advantages[: self.ptr] = (adv - adv.mean()) / (adv.std() + 1e-8)

    def get_minibatches(self, batch_size: int):
        idxs = np.random.permutation(self.ptr)
        for start in range(0, self.ptr, batch_size):
            end = start + batch_size
            mb_idx = idxs[start:end]
            yield (
                self.obs[mb_idx],
                self.actions[mb_idx],
                self.logprobs[mb_idx],
                self.advantages[mb_idx],
                self.returns[mb_idx],
            )

    def clear(self):
        self.ptr = 0
        self.full = False


def select_behavior_name(env: UnityEnvironment) -> str:
    specs = env.behavior_specs
    if len(specs) == 0:
        raise RuntimeError("No behaviors found. Ensure the Unity scene is running with a BehaviorParameters component.")
    # If multiple, pick the first; you can filter by name if needed
    return list(specs.keys())[0]


def main():
    cfg = PPOConfig()
    print(f"Using device: {cfg.device}")

    # Connect to Unity Editor on a specific port (file_name=None connects to Editor)
    env = UnityEnvironment(file_name=None, seed=1, side_channels=[], base_port=cfg.base_port)
    env.reset()
    behavior_name = select_behavior_name(env)
    spec = env.behavior_specs[behavior_name]

    if spec.is_action_discrete():
        raise RuntimeError("This script assumes continuous actions. Set BehaviorParameters to Continuous with size 2.")

    obs_shape = spec.observation_specs[0].shape[0]
    act_dim = spec.action_spec.continuous_size

    print(f"Behavior: {behavior_name} | obs_dim={obs_shape} act_dim={act_dim}")

    policy = ActorCritic(obs_shape, act_dim).to(cfg.device)
    optimizer = optim.Adam(policy.parameters(), lr=cfg.learning_rate)

    buffer = RolloutBuffer(cfg.rollout_steps, obs_shape, act_dim, cfg.device)

    global_step = 0
    episode_returns = []
    episode_return = 0.0
    update_count = 0
    start_time = time.time()

    print(f"Starting training... Target: {cfg.total_timesteps:,} steps")
    print("=" * 60)

    while global_step < cfg.total_timesteps:
        # Collect rollout
        buffer.clear()
        while not buffer.full:
            decision_steps, terminal_steps = env.get_steps(behavior_name)

            # Support single-agent only for simplicity
            if len(decision_steps) > 1:
                raise RuntimeError("This script currently supports a single agent. Reduce agents in the scene.")

            # If an agent terminated last frame, log and continue
            for agent_id_terminated in terminal_steps.agent_id_to_index.keys():
                term_step = terminal_steps[agent_id_terminated]
                episode_return += float(term_step.reward)
                episode_returns.append(episode_return)
                episode_return = 0.0

            if len(decision_steps) == 0:
                # No agent requesting a decision this frame; step once
                env.step()
                continue

            agent_id = decision_steps.agent_id[0]
            obs_np = decision_steps.obs[0][0]  # first (and only) agent, first observation
            reward = float(decision_steps.reward[0])
            episode_return += reward

            obs = torch.tensor(obs_np, dtype=torch.float32, device=cfg.device)
            with torch.no_grad():
                action, logprob, value = policy.act(obs.unsqueeze(0))
            action_np = action.squeeze(0).cpu().numpy()

            # Store into buffer (done is 0 here; will be handled when terminal arrives)
            buffer.add(obs, action.squeeze(0), logprob.squeeze(0), reward, 0.0, value.squeeze(0))

            # Apply action
            action_tuple = ActionTuple(continuous=action_np.reshape(1, -1))
            env.set_actions(behavior_name, action_tuple)
            env.step()
            global_step += 1

        # Bootstrap value for the last observed state
        decision_steps, terminal_steps = env.get_steps(behavior_name)
        if len(terminal_steps) > 0:
            # If episode ended exactly at the end of rollout, last_value = 0 (no bootstrap across episodes)
            last_value = 0.0
        else:
            if len(decision_steps) == 0:
                # step once to get a state if needed
                env.step()
                decision_steps, terminal_steps = env.get_steps(behavior_name)
            if len(decision_steps) > 0:
                obs_np = decision_steps.obs[0][0]
                with torch.no_grad():
                    _, _, v = policy.forward(torch.tensor(obs_np, dtype=torch.float32, device=cfg.device).unsqueeze(0))
                last_value = float(v.squeeze(0).cpu().item())
            else:
                last_value = 0.0

        buffer.compute_gae(last_value, cfg.gamma, cfg.gae_lambda)

        # PPO update
        for epoch in range(cfg.ppo_epochs):
            for mb_obs, mb_actions, mb_logprobs, mb_adv, mb_returns in buffer.get_minibatches(cfg.minibatch_size):
                new_logprob, entropy, values = policy.evaluate_actions(mb_obs, mb_actions)

                ratio = torch.exp(new_logprob - mb_logprobs)
                pg_loss1 = -mb_adv * ratio
                pg_loss2 = -mb_adv * torch.clamp(ratio, 1.0 - cfg.clip_coef, 1.0 + cfg.clip_coef)
                pg_loss = torch.max(pg_loss1, pg_loss2).mean()

                value_loss = 0.5 * (mb_returns - values).pow(2).mean()
                entropy_loss = -entropy.mean()

                loss = pg_loss + cfg.value_coef * value_loss + cfg.entropy_coef * entropy_loss

                optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(policy.parameters(), cfg.max_grad_norm)
                optimizer.step()

        update_count += 1
        progress = global_step / cfg.total_timesteps * 100
        elapsed_time = time.time() - start_time
        
        # 업데이트 주기마다 상세 정보 출력
        if len(episode_returns) > 0:
            recent_reward = episode_returns[-1]
            avg_100 = np.mean(episode_returns[-100:])
            avg_10 = np.mean(episode_returns[-10:]) if len(episode_returns) >= 10 else recent_reward
            
            print(f"Update #{update_count:3d} | Step: {global_step:6d}/{cfg.total_timesteps} ({progress:5.1f}%)")
            print(f"  Episodes: {len(episode_returns):4d} | Recent: {recent_reward:7.2f} | Avg-10: {avg_10:7.2f} | Avg-100: {avg_100:7.2f}")
            print(f"  Elapsed: {elapsed_time/60:.1f}min | ETA: {elapsed_time/progress*100/60:.1f}min")
            print("-" * 60)
        else:
            print(f"Update #{update_count:3d} | Step: {global_step:6d} | Collecting episodes... ({progress:5.1f}%)")
            print("-" * 60)

    # Save policy
    save_path = os.path.join(os.path.dirname(__file__), "car_ppo_policy.pt")
    torch.save(policy.state_dict(), save_path)
    print(f"Saved policy to {save_path}")
    
    # Export to ONNX
    policy.eval()
    dummy_input = torch.randn(1, obs_shape, device=cfg.device)
    onnx_path = os.path.join(os.path.dirname(__file__), "car_ppo_policy.onnx")
    
    try:
        torch.onnx.export(
            policy,
            dummy_input,
            onnx_path,
            export_params=True,
            opset_version=11,
            do_constant_folding=True,
            input_names=['observation'],
            output_names=['continuous_actions', 'continuous_action_log_probs', 'value_estimates'],
            dynamic_axes={
                'observation': {0: 'batch_size'},
                'continuous_actions': {0: 'batch_size'},
                'continuous_action_log_probs': {0: 'batch_size'},
                'value_estimates': {0: 'batch_size'}
            }
        )
        print(f"Saved ONNX model to {onnx_path}")
    except Exception as e:
        print(f"Failed to export ONNX: {e}")

    env.close()


if __name__ == "__main__":
    main()


