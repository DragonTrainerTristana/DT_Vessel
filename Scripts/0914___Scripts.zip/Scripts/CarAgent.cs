using System.Collections.Generic;
using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Sensors;

public class CarAgent : Agent
{
    [Header("Scene References")]
    public CarController carController;
    public Transform targetTransform;
    public Transform spawnPoint;

    [Header("Observations")]
    public float rayDistance = 15f;
    public LayerMask rayLayerMask;
    public List<float> rayAngles = new List<float> { -90f, -60f, -30f, -15f, 0f, 15f, 30f, 60f, 90f };

    [Header("Rewards")]
    public float stepPenalty = -0.001f;
    public float reachTargetReward = 2.0f;
    public float collisionPenalty = -1.0f;
    public float distanceRewardScale = 0.02f;

    float previousDistanceToTarget;

    public override void Initialize()
    {
        if (carController == null)
        {
            carController = GetComponent<CarController>();
        }
    }

    public override void OnEpisodeBegin()
    {
        if (carController != null && spawnPoint != null)
        {
            Vector3 pos = spawnPoint.position;
            Quaternion rot = spawnPoint.rotation;
            carController.ResetCar(pos, rot);
        }

        previousDistanceToTarget = GetDistanceToTarget();
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        // Car local velocity (x, z)
        Vector3 localVel = carController != null ? carController.GetLocalVelocity() : Vector3.zero;
        sensor.AddObservation(localVel.x);
        sensor.AddObservation(localVel.z);

        // Direction to target in local space (x, z) and normalized distance
        Vector3 toTarget = targetTransform != null ? (targetTransform.position - transform.position) : Vector3.zero;
        float distance = toTarget.magnitude;
        Vector3 localToTarget = transform.InverseTransformDirection(toTarget.normalized);
        sensor.AddObservation(localToTarget.x);
        sensor.AddObservation(localToTarget.z);
        sensor.AddObservation(Mathf.Clamp01(distance / rayDistance));

        // Simple angle alignment
        float facingDot = Vector3.Dot(transform.forward, toTarget.normalized);
        sensor.AddObservation(facingDot);

        // Raycasts distances
        for (int i = 0; i < rayAngles.Count; i++)
        {
            float angle = rayAngles[i];
            Vector3 dir = Quaternion.Euler(0f, angle, 0f) * transform.forward;
            float normDist = 1f;
            if (Physics.Raycast(transform.position + Vector3.up * 0.2f, dir, out RaycastHit hit, rayDistance, rayLayerMask.value))
            {
                normDist = hit.distance / rayDistance;
            }
            sensor.AddObservation(normDist);
        }
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        float steer = Mathf.Clamp(actions.ContinuousActions[0], -1f, 1f);
        float accel = Mathf.Clamp(actions.ContinuousActions[1], -1f, 1f);

        if (carController != null)
        {
            carController.Move(steer, accel);
        }

        // Shaping: reward based on progress towards target
        float currentDistance = GetDistanceToTarget();
        float progress = previousDistanceToTarget - currentDistance;
        AddReward(distanceRewardScale * progress);
        previousDistanceToTarget = currentDistance;

        // Step penalty to encourage faster solutions
        AddReward(stepPenalty);

        // Success check
        if (currentDistance < 1.2f)
        {
            AddReward(reachTargetReward);
            EndEpisode();
        }
    }

    public override void Heuristic(in ActionBuffers actionsOut)
    {
        var continuous = actionsOut.ContinuousActions;
        float steer = Input.GetAxis("Horizontal");
        float accel = Input.GetAxis("Vertical");
        continuous[0] = steer;
        continuous[1] = accel;
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.collider != null && collision.collider.gameObject != null)
        {
            string tag = collision.collider.gameObject.tag;
            if (tag == "Obstacle" || tag == "Wall")
            {
                AddReward(collisionPenalty);
                EndEpisode();
            }
        }
    }

    float GetDistanceToTarget()
    {
        if (targetTransform == null) return 0f;
        return Vector3.Distance(transform.position, targetTransform.position);
    }
}


